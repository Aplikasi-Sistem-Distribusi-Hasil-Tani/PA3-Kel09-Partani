<?php $__env->startSection('content'); ?>
    <!-- Content -->
    <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="fw-bold py-3 mb-4">
            <?php echo e($title); ?>

        </h4>
        <div class="row">
            <div class="col-md-12">
                <div class="card mb-4">
                    <h5 class="card-header">Profile pelapor</h5>
                    <div class="card-body">
                        <div class="d-flex align-items-start align-items-sm-center gap-4">
                            <img src="<?php echo e(asset('assets/img/avatars/1.png')); ?>" alt="user-avatar" class="d-block rounded"
                                height="100" width="100" id="uploadedAvatar">
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="mb-3 col-md-6">
                                <label for="full_name" class="form-label">Nama Lengkap</label>
                                <input class="form-control" type="text" id="full_name" name="full_name"
                                    value="<?php echo e($laporan->user->full_name); ?>" readonly>
                            </div>

                            <div class="mb-3 col-md-6">
                                <label for="lastName" class="form-label">Email</label>
                                <input class="form-control" type="text" name="lastName" id="lastName"
                                    value="<?php echo e($laporan->user->email); ?>" readonly>
                            </div>
                            <div class="mb-3 col-md-6">
                                <label for="email" class="form-label">Nomor Handphone</label>
                                <input class="form-control" type="text" id="email" name="email"
                                    value="<?php echo e($laporan->user->nohp); ?>" readonly>
                            </div>
                            <div class="mb-3 col-md-6">
                                <label for="organization" class="form-label">Username</label>
                                <input type="text" class="form-control" id="organization" name="organization"
                                    value="<?php echo e($laporan->user->username); ?>" readonly>
                            </div>
                            <hr class="my-3">
                            <h5 class="card-header text-center">Isi Laporan</h5>
                            <div class="mb-3 col-md-6">
                                <label class="form-label" for="phoneNumber">Judul Laporan</label>
                                <div class="input-group input-group-merge">
                                    <input type="text" id="phoneNumber" name="phoneNumber" class="form-control"
                                        value="<?php echo e($laporan->judul_pelaporan); ?>" readonly>
                                </div>
                            </div>
                            <div class="mb-3 col-md-6">
                                <label for="address" class="form-label">Lokasi Kejadian</label>
                                <input type="text" class="form-control" id="address" name="address"
                                    value="<?php echo e($laporan->lokasi_kejadian); ?>" readonly>
                            </div>
                            <div class="mb-3 col-md-6">
                                <label for="address" class="form-label">Tanggal Kejadian</label>
                                <input type="text" class="form-control" id="address" name="address"
                                    value="<?php echo e(\Carbon\Carbon::parse($laporan->tanggal_kejadian)->format('l, j F Y H:i:s')); ?>"
                                    readonly>

                            </div>
                            <div class="mb-3 col-md-12">
                                <label for="state" class="form-label">Isi Laporan</label>
                                <textarea class="form-control" id="exampleFormControlTextarea1" rows="5" readonly><?php echo e($laporan->isi_laporan); ?></textarea>
                            </div>
                        </div>
                        <form action="<?php echo e(route('laporan-masyarakat.proses', $laporan->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <hr class="my-3">
                            <h5 class="card-header text-center">Pesan Anda</h5>
                            <div class="mb-3 col-md-12">
                                <div class="mb-3 col-md-12">
                                    <label for="state" class="form-label">Pesan Anda kepada Pelapor</label>
                                    <textarea class="form-control" name="catatan_petugas" rows="5"><?php echo e($laporan->catatan_petugas); ?></textarea>
                                </div>
                            </div>
                            <div class="mt-2">
                                <button type="submit" class="btn btn-primary me-2">Prosess</button>
                                <a href="<?php echo e(route('laporan-masyarakat.index')); ?>"
                                    class="btn btn-outline-secondary">Cancel</a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.superadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Materi Kuliah\SEMESTER 5\KREN\Tangani kekerasan\Tangani-kekerasan\resources\views/superadmin/laporan_detail.blade.php ENDPATH**/ ?>