<?php $__env->startSection('content'); ?>
    <!-- Bordered Table -->
    <div class="card">
        <h3 class="card-header text-center">Laporan Masyarakat</h3>
        <div class="card-body">
            <div class="table-responsive text-nowrap">
                <table class="table table-bordered">
                    <thead>
                        <tr class="text-center">
                            <th>Nama Pelpor</th>
                            <th>Judul Laporan</th>
                            <th>Foto Pelapor</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $laporans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $laporan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr class="text-center">
                                <td>
                                    <i class="fab fa-bootstrap fa-lg text-primary me-3"></i>
                                    <strong><?php echo e($laporan->user->full_name); ?></strong>
                                </td>
                                <td><?php echo e($laporan->judul_pelaporan); ?></td>
                                <td>
                                    <img src="<?php echo e(asset('assets/img/avatars/5.png')); ?>" alt="Avatar" class="rounded-circle"
                                        height="44px">
                                </td>
                                <td>
                                    <span class="badge bg-label-warning me-1"><?php echo e($laporan->status); ?></span>
                                </td>
                                <td class="text-center">
                                    <a href="<?php echo e(route('laporan-masyarakat.show', $laporan->id)); ?>" class="btn btn-sm btn-info">Detail</a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="8">
                                    <h1>Tidak ada data laporan</h1>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <div>
            <?php echo e($laporans->links()); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.superadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Materi Kuliah\SEMESTER 5\KREN\Tangani kekerasan\Tangani-kekerasan\resources\views/superadmin/laporan_masyarakat_index.blade.php ENDPATH**/ ?>